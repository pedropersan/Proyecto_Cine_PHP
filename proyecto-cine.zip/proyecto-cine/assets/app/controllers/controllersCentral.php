<?php
include "assets/app/controllers/controllersUsuario.php";
$accion=$_REQUEST['ctl'] ?? 'inicio';
switch($accion){
    case 'inicio':
        break;
    case 'login':
        break;
    case 'registro':
        (new controllersUsuario())->registrarUsuario();
        break;
    
}