<?php
class controllersUsuario{
    public function registrarUsuario()
    {
        include "assets/templates/formularioRegistro.php";
    }
}