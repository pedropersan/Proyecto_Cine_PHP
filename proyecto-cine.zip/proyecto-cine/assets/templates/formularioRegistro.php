<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/app/css/style_formularioRegistro.css">
    <title>Formulario de Registro</title>
</head>
<body>
    <div>
        <h2>Formulario de Registro</h2>
            <form action="index.php" action="index.php?ctl=registro" method="POST">
                <label for="nombre">Nombre:</label>
                <br>
                    <input type="text" id="nombre" name="nombre" value="">
                <br>
                <label for="apellidos">Apellidos:</label>
                <br>
                    <input type="text" id="apellidos" name="apellidos" value="">
                <br>
                <label for="contraseña">Contraseña:</label>
                <br>
                    <input type="text" id="contraseña" name="contraseña" value="">
                <br>
                <label for="contraseñaRepetir">Repetir Contraseña:</label>
                <br>
                    <input type="text" id="contraseñarepetida" name="contraseñaRepetida" value="">
                <br>
                <label for="gmail">Gmail:</label>
                <br>
                    <input type="email" id="gmail" name="gmail" value="">
                <br>
                <input type="submit" name="enviar" value="Enviar">
        </form>
    </div>
</body>
</html>