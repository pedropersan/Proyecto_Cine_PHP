<header>
    <img src="/assets/images/logo.png" alt="logo_de_cine">
    <nav>
        <ul>
            
        </ul>
    </nav>
</header>
