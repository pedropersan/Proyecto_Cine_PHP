
<header>
    <img src="../assets/images/logo.png" alt="logo_de_cine">
    <div>
        <input type="submit" class="iniciarSesion"  name="iniciar" value="Iniciar Sesión"></input>
        <button><a href="index.php?ctl=registro"></a>Registrarse</button>

    </div>
</header>
